package edu.buffalo.cse.cse486586.simpledht;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.HashMap;
import java.util.LinkedHashMap;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;

public class SimpleDhtProvider extends ContentProvider {

//The basic code of listing the file , deleting files and similar mechanical operations
    //has been taken from Android documentation and StackOverflow mostly. Rest all logic and code is
    //my own.
    Node succ, pred = null;
    public String myPort, myHash;
    private Uri mUri;
    private ArrayList<String> keyMap = new ArrayList<String>();
    boolean isDataSingle, isDataGlobal = false;
    StringBuffer totalRecord, totalRecordGlobal;
    HashMap<String, String> queryMap = new HashMap<String, String>();

    public class Node {
        public String port;
        public String hash;

        public Node(String port, String selfHash) {
            this.port = port;
            this.hash = selfHash;
        }
    }

    public LinkedHashMap<String, Node> serverMap;

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        if (selection.equals("@")) {
            deleteAll();
            return 1;
        }
        if (selection.equals("*")) {
            if (pred == null && succ == null) {
                Log.info("Only Node deletion *");
                deleteAll();
                return 1;
            } else {
                deleteAll();
                new ClientDeletion().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, succ.port,"*");

            }
            return 1;
        }
        else {
            if((pred==null&&succ==null) ||isMYNode(genHash(selection)))
            {
                deleteOne(selection);
            }
            else{
                new ClientDeletion().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, succ.port,selection);
            }

        }

        return 0;
    }

    //https://stackoverflow.com/questions/28775949/what-path-does-getapplicationcontext-getfilesdir-return
    //https://stackoverflow.com/questions/5486529/delete-file-from-internal-storage
    public void deleteAll() {
        File dirFiles = getContext().getFilesDir();
        for (String fileName : dirFiles.list()) {
            getContext().deleteFile(fileName);
        }
    }

    public void deleteOne(String fileName) {
            Log.info("Deleting Single file:"+fileName);
            getContext().deleteFile(fileName);
        }

    @Override
    public String getType(Uri uri) {
        // TODO Auto-generated method stub
        return null;
    }

    private Uri buildUri(String scheme, String authority) {
        Uri.Builder uriBuilder = new Uri.Builder();
        uriBuilder.authority(authority);
        uriBuilder.scheme(scheme);
        return uriBuilder.build();
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        // TODO Auto-generated method stub
        //  Log.info("URG"+succ.port+"AND"+pred.port);

        String key = values.getAsString("key");
        String value = values.getAsString("value");
        Log.info("Insert:" + key + "AND" + value);
        if ((pred == null && succ == null) || isMYNode(genHash(key))) {
            Log.info("Insert my node:" + key + "AND" + value);
            //Case where data will be inserted at me

            Context ctx = getContext();
            //Hit and Trial to extract the values
            String keytoBeStored = key;
            String valueTobeStored = value;
            keyMap.add(keytoBeStored);
            //PA1 how to write a file.
            FileOutputStream outputStream;
            try {
                outputStream = ctx.openFileOutput(keytoBeStored, Context.MODE_PRIVATE);
                outputStream.write(valueTobeStored.getBytes());
                outputStream.close();
            } catch (Exception e) {
                Log.v("insert", "error in writing to file");
            }
            Log.v("insert", values.toString());
            return uri;

        } else {
            //send message to successor node with this data.
            sendMessage(succ.port, "Insert;" + key + ";" + value);
        }


        return uri;
    }

    @Override
    public boolean onCreate() {

        mUri = buildUri("content", "edu.buffalo.cse.cse486586.simpledht.provider");
        TelephonyManager tel = (TelephonyManager) this.getContext().getSystemService(Context.TELEPHONY_SERVICE);
        myPort = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);

        //have to multiply by 2 everywhere for actual port
        //  myPort = String.valueOf((Integer.parseInt(portStr) * 2));
        System.out.print("MYPORT" + myPort);
        myHash = genHash(myPort);

        serverMap = new LinkedHashMap<String, Node>();
        //  serverMap.put(myPort,new Node(null,null,genHash(myPort)));

        try {

            ServerSocket serverSocket = new ServerSocket(10000);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);

            if (!myPort.equals("5554")) {
                sendMessage("5554", "Join;" + myPort);
            }

        } catch (IOException e) {

            Log.info("OnCreate Server Exception" + e.getMessage());

        }
        return false;
    }

    public void sendMessage(String port, String msg) {
        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, port, msg);
    }

    public String readFromFile(String key) {
        String fileName = key;
        String data = null;

        try {
            //Reading Value from File :
            //https://stackoverflow.com/questions/9095610/android-fileinputstream-read-txt-file-to-string
            FileInputStream contentFile = getContext().openFileInput(fileName);

            StringBuffer fileContent = new StringBuffer("");
            byte[] buffer = new byte[1024];

            int ne;
            while ((ne = contentFile.read(buffer)) != -1) {
                fileContent.append(new String(buffer, 0, ne));
            }
            data = fileContent.toString();


        } catch (Exception e) {

        }
        return data;
    }

    public String readAllFromFile() {
        StringBuffer dataTotal = new StringBuffer();
        String data = null;

        try {
            //Reading Value from File :
            //https://stackoverflow.com/questions/9095610/android-fileinputstream-read-txt-file-to-string
            File dirFiles = getContext().getFilesDir();
            for (String fileName : dirFiles.list()) {
                FileInputStream contentFile = getContext().openFileInput(fileName);

                StringBuffer fileContent = new StringBuffer("");
                byte[] buffer = new byte[1024];

                int ne;
                while ((ne = contentFile.read(buffer)) != -1) {
                    fileContent.append(new String(buffer, 0, ne));
                }
                data = fileContent.toString();
                dataTotal.append(fileName).append(";").append(data).append("|");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.info("All Query Data" + dataTotal);
        return dataTotal.toString();
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
                        String sortOrder) {


        isDataGlobal = false;
        isDataSingle = false;
        MatrixCursor mCursor = new MatrixCursor(new String[]{"key", "value"});
        Log.info("Enterin for Query KEy:" + selection);
        if (selection.equals("*")) {

            if (pred == null && succ == null) {
                String valueAll = readAllFromFile();
                //separate from string all values
                Log.info("Query with *" + valueAll);
                String[] rows = valueAll.split("\\|");
                Log.info("Value All spliting in * Query" + rows.length);
                for (String vals : rows) {
                    Log.info("Query with @ 2" + vals);
                    if (!(vals == null)) {
                        String key = (vals.split(";"))[0];
                        String valuee = (vals.split(";"))[1];
                        mCursor.addRow(new String[]{key, valuee});
                    }
                }
            } else {
                //Multicast Message and get the result
                Log.info("Query with *");
                sendQueryMessage(selection);
                while (!isDataGlobal) {

                }
                Log.info("Query with *2" + totalRecordGlobal.toString());
                totalRecordGlobal.append(readAllFromFile());
                Log.info("Query with *3" + totalRecordGlobal.toString());
                String[] rows = totalRecordGlobal.toString().split("\\|");
                for (String vals : rows) {
                    if (!(vals == null)) {
                        String key = (vals.split(";"))[0];
                        String valuee = (vals.split(";"))[1];
                        Log.info("Query with * 4" + key + "AND" + valuee);
                        mCursor.addRow(new String[]{key, valuee});
                    }
                }
            }
        } else if (selection.equals("@")) {
            //get only self result
            String valueAll = readAllFromFile();
            //separate from string all values
            Log.info("Query with @" + valueAll);
            String[] rows = valueAll.split("\\|");
            Log.info("Value All spliting in @ Query" + rows.length);
            for (String vals : rows) {
                Log.info("Query with @ 2" + vals);
                if (!(vals == null)) {
                    String key = (vals.split(";"))[0];
                    String valuee = (vals.split(";"))[1];
                    mCursor.addRow(new String[]{key, valuee});
                }
            }
        } else if ((pred == null && succ == null) || isMYNode(genHash(selection))) {
            Log.info("I have the Query Data");
            //Code to fetch the data
            String value = readFromFile(selection);
            mCursor.addRow(new String[]{selection, value});
        } else {
            //ReDirect to Node that has the data
            //keep holding the data for query
            Log.info("Query Sending to Successor");
            sendQueryMessage(selection);
            while (!isDataSingle) {
            }
            String value = totalRecord.toString();

            Log.info("Query Sending to Successor Done" + value + ":" + selection);
            mCursor.addRow(new String[]{selection, value});
        }

        mCursor.setNotificationUri(getContext().getContentResolver(), uri);
        return mCursor;
    }


    private void sendQueryMessage(String msg) {

        new ClientQuery().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, succ.port, msg);

    }


    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        return 0;
    }

    private String genHash(String input) {

        try {
            MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
            byte[] sha1Hash = sha1.digest(input.getBytes());
            Formatter formatter = new Formatter();
            for (byte b : sha1Hash) {
                formatter.format("%02x", b);
            }
            return formatter.toString();
        } catch (Exception e) {
            Log.info("Exc Hashing");
        }
        return null;
    }


    //Server Class Starts below

    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

        @Override
        protected Void doInBackground(ServerSocket... sockets) {

            ServerSocket serverSocket = sockets[0];
            try {
                while (true) {
                    String message;

                    Socket clientSocket = serverSocket.accept();
                    PrintWriter pos = new PrintWriter(clientSocket.getOutputStream(), true);
                    InputStreamReader inputRead = new InputStreamReader(clientSocket.getInputStream());
                    BufferedReader bufferRead = new BufferedReader(inputRead);

                    //FIRST MSG ARRIVED FROM CLIENT
                    message = bufferRead.readLine();
                    Log.info("SERVER FIRST MESSAGE Recieved  " + message);
                    if (message.contains("Join")) {
                        Log.info("Inside First Server Check Join ");
                        String firstMessageAray[] = message.split(";");

                        String port = firstMessageAray[1];
                        Log.info("Port for which i need to check " + port);
                        String hash = genHash(port);
                        if (succ == null && pred == null) {
                            //Initial Case
                            Node node = new Node(port, hash);
                            succ = pred = node;
                            pos.println("C1;" + myPort);
                        }
                        // serverMap.put(port,new Node())
//                        else if (hash.compareTo(myHash)<0&&(hash.compareTo(pred.hash)>0)||
//                                (myHash.compareTo(hash)<0&&pred.hash.compareTo(myHash)>0)){
                        else if (isMYNode(hash)) {
                            //Node is my responsibility..
                            pos.println("CLOSE");
                            Node predNodeTemp = new Node(port, hash);

                            Log.info("SERVER My Node  " + port);
                            //Send Msg to Pred Node to update Succ Node.
                            sendMessage(pred.port, "Succ;" + port);
                            sendMessage(port, "NewNode;" + pred.port + ";" + myPort);
                            //pos.println(myPort+";"+pred.port); //sending back to Node 2 the details
                            pred = predNodeTemp; // update self pred
                        } else {
                            pos.println("CLOSE");
                            Log.info("SERVER Sending Msg to Successor for Port: " + port);
                            sendMessage(succ.port, "Join;" + port);
                            //Send the current request to successor to handle..
                            //MSG to Successor to handle this node. hash and myHash
                        }
                    } else if (message.contains("Succ")) {
                        //update successor message
                        pos.println("CLOSE");

                        String finalMessage[] = message.split(";");
                        Node succNode = new Node(finalMessage[1], genHash(finalMessage[1]));
                        succ = succNode;
                        Log.info("SERVER updating my succ to new succ  " + myPort + finalMessage[1]);
                    } else if (message.contains("NewNode")) {
                        //Got message to update my successor and predecessor
                        pos.println("CLOSE");
                        String finalMessage[] = message.split(";");
                        Node predNode = new Node(finalMessage[1], genHash(finalMessage[1]));
                        Node succNode = new Node(finalMessage[2], genHash(finalMessage[2]));
                        pred = predNode;
                        succ = succNode;
                        Log.info("SERVER I am a new Node  " + myPort + finalMessage[1] + finalMessage[2]);

                    } else if (message.contains("Insert")) {
                        ContentValues mContentValues = new ContentValues();
                        mContentValues.put("key", (message.split(";"))[1]);
                        mContentValues.put("value", (message.split(";"))[2]);
                        insert(mUri, mContentValues);
                        pos.println("CLOSE");
                    } else if (message.contains("Query")) {
                        if (!message.contains("*")) {
                            if (isMYNode(genHash((message.split(";"))[1]))) {
                                //Mere me hain key
                                //Send true and send data
                                pos.println("true");
                                pos.println(readFromFile((message.split(";"))[1]));
                            } else {
                                Log.info("server Not my data" + message);
                                pos.println(succ.port);
                            }
                        } else {
                            Log.info("Server All Query");
                            pos.println(succ.port);
                            pos.println(readAllFromFile());
                            //* send all recordssd

                        }
                        //* then give all records else search for self record and send it back
                        //  query(mUri,null,(message.split(";"))[1],null,null);
                    }
                    else if(message.contains("Delete"))
                    {
                        if(message.contains("*"))
                        {
                            deleteAll();
                            pos.println(succ.port);
                        }
                        else {

                             if(isMYNode((message.split(";"))[1]))
                             {
                                 pos.println("true");
                                 deleteOne((message.split(";"))[1]);
                             }
                             else{
                                 pos.println(succ.port);
                             }
                        }
                    }
                    Log.info("Going in While");
                }
            } catch (Exception e) {

            }
            return null;
        }
    }

    private boolean isMYNode(String hash) {
        return (hash.compareTo(pred.hash) > 0 && (
                pred.hash.compareTo(myHash) > 0 || myHash.compareTo(hash) > 0
        )) || (myHash.compareTo(pred.hash) < 0 && hash.compareTo(myHash) < 0);
    }


    private class ClientTask extends AsyncTask<Object, Void, Void> {
        @Override
        protected Void doInBackground(Object... msgs) {


            String msg = (String) msgs[1];
            String portT = (String) msgs[0];
            String portToConnect = String.valueOf((Integer.parseInt(portT) * 2));
            Socket socket;
            Log.info("Client Entering to send message");
            try {
                socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(portToConnect));
                PrintWriter printWriter = new PrintWriter(socket.getOutputStream(), true);
                printWriter.println(msg);
                Log.info("  MSG sent from client" + msg + portToConnect);
                InputStreamReader isr = new InputStreamReader(socket.getInputStream());
                BufferedReader inputBuffer = new BufferedReader(isr);
                String recMsg = inputBuffer.readLine();
                if (recMsg.contains("C1")) {
                    Log.info("Client 2 Nodes only" + recMsg);
                    String portGot = (recMsg.split(";"))[1];
                    Log.info(portGot);
                    Node succPred = new Node(portGot, genHash(portGot));
                    pred = succPred;
                    succ = succPred;
                }
                inputBuffer.close();
                socket.close();
            } catch (Exception e) {
                e.printStackTrace();
                succ = null;
                pred = null;
            }
            return null;
        }


    }

    private class ClientQuery extends AsyncTask<Object, Void, Void> {
        @Override
        protected Void doInBackground(Object... msgs) {
            String msg = (String) msgs[1];
            String portSucc = (String) msgs[0];
            String portToConnect = String.valueOf((Integer.parseInt(portSucc) * 2));
            String nextSucc = "";
            Socket socket[] = new Socket[5];
            Log.info("Client Entering to send message");
            totalRecord = new StringBuffer();
            totalRecordGlobal = new StringBuffer();
            if (!msg.contains("*")) {
                Log.info("Query for single data" + msg);
                //msg1 will contain succ selection criteria

                int i = -1;
                while (!isDataSingle) {
                    try {
                        socket[++i] = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                Integer.parseInt(portToConnect));
                        PrintWriter printWriter = new PrintWriter(socket[i].getOutputStream(), true);
                        printWriter.println("Query;" + msg); //msg is Key to be searched
                        Log.info("Query Client single Data" + portToConnect);
                        InputStreamReader isr = new InputStreamReader(socket[i].getInputStream());
                        BufferedReader inputBuffer = new BufferedReader(isr);
                        String portNext = inputBuffer.readLine();
                        if (portNext.equals("true")) {   //send data only without key
                            totalRecord.append(inputBuffer.readLine());
                            isDataSingle = true;
                        } else { //send just the successor port
                            Log.info("query Data NO Port" + portToConnect);
                            portToConnect = String.valueOf((Integer.parseInt(portNext) * 2));
                        }
                        inputBuffer.close();
                        socket[i].close();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                return null;
            }
            int i = -1;
            while (!nextSucc.equals(myPort)) {
                try {

                    socket[++i] = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(portToConnect));
                    PrintWriter printWriter = new PrintWriter(socket[i].getOutputStream(), true);
                    printWriter.println("Query*;");
                    Log.info("Query ** client" + portToConnect);
                    InputStreamReader isr = new InputStreamReader(socket[i].getInputStream());
                    BufferedReader inputBuffer = new BufferedReader(isr);
                    String portNext = inputBuffer.readLine();
                    //  totalRecord.append(inputBuffer.readLine());

                    String records = inputBuffer.readLine();
                    {
                        if (!(records == null)) {
                            totalRecordGlobal.append(records);
                            //queryMap.put((rec.split(";"))[0], (rec.split(";"))[1]);
                            Log.info(totalRecordGlobal.toString());
                        }
                    }
                    nextSucc = portNext;
                    portToConnect = String.valueOf((Integer.parseInt(nextSucc) * 2));
                    inputBuffer.close();
                    socket[i].close();
                    // totalRecord.append("$");  //Records from different nodes will be separated by $
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
            isDataGlobal = true;

            return null;
        }
    }

    private class ClientDeletion extends AsyncTask<Object, Void, Void> {
        @Override
        protected Void doInBackground(Object... msgs) {
            String msg = (String) msgs[1];
            String portSucc = (String) msgs[0];
            String portToConnect = String.valueOf((Integer.parseInt(portSucc) * 2));
            String nextSucc = "";
            Socket socket[] = new Socket[5];
            Log.info("Client Entering to send message Delete");
            if (msg.contains("*")) {  //Delete All
                int i = -1;
                while (!nextSucc.equals(myPort)) {
                    try {

                        socket[++i] = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                Integer.parseInt(portToConnect));
                        PrintWriter printWriter = new PrintWriter(socket[i].getOutputStream(), true);
                        printWriter.println("Delete*;");
                        Log.info("Delete* client" + portToConnect);
                        InputStreamReader isr = new InputStreamReader(socket[i].getInputStream());
                        BufferedReader inputBuffer = new BufferedReader(isr);
                        String portNext = inputBuffer.readLine();
                        nextSucc = portNext;
                        portToConnect = String.valueOf((Integer.parseInt(nextSucc) * 2));
                        inputBuffer.close();
                        socket[i].close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                return null;
            } else {       //Delete specific data
                Log.info("Delete for single data" + msg);
                int i = -1;
                while (true) {
                    try {
                        socket[++i] = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                Integer.parseInt(portToConnect));
                        socket[++i].setSoTimeout(1200);
                        socket[++i].setTcpNoDelay(true);
                        PrintWriter printWriter = new PrintWriter(socket[i].getOutputStream(), true);
                        printWriter.println("Delete;" + msg); //msg is Key to be deleted
                        Log.info("Delete Client single Data" + portToConnect);
                        InputStreamReader isr = new InputStreamReader(socket[i].getInputStream());
                        BufferedReader inputBuffer = new BufferedReader(isr);
                        String portNext = inputBuffer.readLine();
                        if (portNext.equals("true")) {   //send data only without key
                            break;
                        } else { //send just the successor port
                            Log.info("Delete Client next Port" + portToConnect);
                            portToConnect = String.valueOf((Integer.parseInt(portNext) * 2));
                        }
                        inputBuffer.close();
                        socket[i].close();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                return null;


            }
        }

    }

}